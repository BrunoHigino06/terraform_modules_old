# aws-route_table
Módulo de un recurso de tabla de rutas especifica cómo se enrutan los paquetes de red en una VPC (Virtual Private Cloud).

## Usage:

```terraform
module "route_table" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  routes = var.routes
  vpc_id = var.vpc_id
  tags   = var.tags
}
```
#