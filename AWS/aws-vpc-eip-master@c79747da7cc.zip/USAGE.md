# aws-nat_eip
Módulo de un recurso de IP elástica (Elastic IP) con etiquetas específicas.

## Usage:

```terraform
module "eip" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  eip_names = var.eip_names
  eip-tags  = var.eip-tags
}
```
#