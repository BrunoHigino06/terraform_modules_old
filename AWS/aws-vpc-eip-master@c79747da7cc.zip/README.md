<!--
** NO EDITE ESTE ARCHIVO
**
** Este archivo fue generado automaticamente por https://git.tools.tbk.cl/projects/DSO/repos/mk-tools/browse
**
** 1) Realice sus cambios en `README.doc.yml`
** 2) Ejecute `make docs/all` para reconstruir todos los *.doc.yml
** 3) Ejecute `make README.md` para reconstruir este archivo
**
-->
# aws-vpc-eip

![Last Release](https://ci.tools.tbk.cl/buildStatus/icon?job=tm%2Faws-vpc-eip%2Fmaster&config=lastRelease) [![Build Status](https://ci.tools.tbk.cl/buildStatus/icon?job=tm%2Faws-vpc-eip%2Fmaster)](https://ci.tools.tbk.cl/job/tm/job/aws-vpc-eip/job/master/) 

- [CHANGELOG.md](CHANGELOG.md)
- [Examples](examples)
- [Jira](url a jira para entregar soporte sobre el componente)
- [Teams](link al canal de teams para entregar soporte)

Recurso `aws_eip` que define la creación de una dirección IP elástica (Elastic IP) en AWS.
## Indice

- [Requirements](#requirements)
- [Providers](#providers)
- [Modules](#modules)
- [Resources](#resources)
- [Inputs](#inputs)
- [Outputs](#outputs)
- [Usage](#)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.12 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 2.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 2.2 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 2.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_eip.eip](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/eip) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_eip"></a> [eip](#input\_eip) | List of elastic ip's to create | <pre>list(object({<br>    name            = string<br>    vpc             = bool<br>    parameter_key   = list(string)<br>    parameter_value = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_tags"></a> [tags](#input\_tags) | Elatic IP address tags | `map(string)` | <pre>{<br>  "Account": "connect2"<br>}</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_eip_allocation_id"></a> [eip\_allocation\_id](#output\_eip\_allocation\_id) | Id of the elastic IP |
# aws-nat_eip
Módulo de un recurso de IP elástica (Elastic IP) con etiquetas específicas.

## Usage:

```terraform
module "eip" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  eip_names = var.eip_names
  eip-tags  = var.eip-tags
}
```
### ¿Como colaborar?

#### Obtención del repositorio y generación del Fork

Genere un fork y luego **trabaje en una rama** de su fork

#### Inicie make-tools

Para hacer uso de los comandos de `make` debe ejecutar el siguiente comando. Esto sólo funcionará si se encuentra en una red de confianza, por ejemplo la VPN.

```shell
$ make mk-init
```

#### Instalación de herramientas (opcional)

Para instalar las herramientas de desarrollo con terraform ejecute el siguiente comando.

```shell
$ make terraform/sdk
```

#### Modificaciones de los modulos

Se sugiere el uso del **IDE vscode** instalando el [plugin de terraform](vscode:extension/HashiCorp.terraform).

```shell
$ code .
```

#### Formato del código

Para asegurar que el código este con un formato correcto ejecute

```shell
$ make terraform/fmt
```

#### Actualización de la versión

Configure en el archivo `pipeline.yml` el atributo `metadata.version` con la versión correcta siguiendo [versionamiento semantico](https://semver.org/spec/v2.0.0.html).

#### Actualización de la documentación

Una vez terminado el desarrollo, actualice la documentación del [CHANGELOG.md](CHANGELOG.md) utilizando como input la información de `CHANGELOG.doc.yml`. Puede generar un template de este archivo ejecutando

```shell
$ make changelog/new
```

Si la version actual en desarrollo no existe en `CHANGELOG.doc.yml` la deberá agregar al comienzo del archivo y si ya existe agregue sus cambios en la version y sección correcta.

La generación del [CHANGELOG.md](CHANGELOG.md) se realiza ejecutando

```shell
$ make CHANGELOG.md
```

Luego actualice el archivo [README.md](README.md) ejecutando `make README.md`. Si quiere agregar información adicional puede utilizar las secciones de `README.doc.yml`, si este archivo no existe lo puede generar ejecutando

```shell
$ make docs/new
```

#### Revision de estandares

El pipeline validará que el código esté construido siguiendo las mejores practicas y estandares de la compañia, para ello ejecute el siguiente comando antes de realizar un commit.

```shell
$ make terraform/validate
```

> Si se produce un error, revise la consola para obtener los detalles.

#### Commit y Pull Request (PR)

La etapa final será enviar los cambios de su rama a Bitbucket.

Cuando el desarrollo este finalizado realice un [rebase](https://www.atlassian.com/es/git/tutorials/rewriting-history/git-rebase) de su código para que quede un historial limpio y sólo los commits importantes. Luego un Pull Request desde su rama a la rama develop del upstream.

