# aws-transit_gateway
Módulo de un recurso de EC2 Transit Gateway con etiquetas específicas.

## Usage:

```terraform
module "transit_gateway" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  name          = var.name
  description   = var.description
  tags          = var.tags
}
```
#
