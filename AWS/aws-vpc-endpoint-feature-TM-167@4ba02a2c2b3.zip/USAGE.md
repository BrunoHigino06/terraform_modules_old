# aws-vpc_endpoints
Módulo de un recurso de endpoints de AWS VPC con etiquetas específicas.

## Usage:
```terraform
module "vpc_endpoints" {
  source = "git::ssh://git@git.tools.tbk.cl/..."
  
  create             = var.create
  vpc_id             = var.vpc_id
  endpoints          = var.endpoints
  security_group_ids = var.security_group_ids
  subnet_ids         = var.subnet_ids
  tags               = var.tags
  timeouts           = var.timeouts
}
```
#