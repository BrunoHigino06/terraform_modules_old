# aws-network_acl
Módulo de un recurso Network ACL (Listas de control de acceso de red) con etiquetas específicas.

## Usage:

```terraform
module "network_acl" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  network_acl = var.network_acl
  tags        = var.tags
}
```
#
