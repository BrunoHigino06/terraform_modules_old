# aws-nat_gateway
Módulo de un recurso puerta de enlace NAT con etiquetas específicas.

## Usage:

```terraform
module "nat_gateway" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  allocation_id    = var.allocation_id
  name             = var.name
  subnet_id        = var.subnet_id
  nat_gateway_tags = var.nat_gateway_tags
}
```
#
