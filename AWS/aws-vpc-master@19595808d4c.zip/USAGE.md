# aws-vpc_subnet
Módulo de VPC (Virtual Private Cloud) creada con un CIDR block específico y se le añade un nombre y etiquetas. Las subredes públicas y privadas son creadas con CIDR blocks y etiquetas específicas.

## Usage:

```terraform
module "vpc" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  vpc_cidr              = var.vpc_cidr
  vpc_tags              = var.vpc_tags
  vpc_name              = var.vpc_name
  public_subnet_cidrs   = var.public_subnet_cidrs
  public_azs            = var.public_azs
  private_subnet_cidrs  = var.private_subnet_cidrs
  private_azs           = var.private_azs
  public_subnet_tags    = var.public_subnet_tags
  private_subnet_tags   = var.private_subnet_tags
}
```
#