<!--
** NO EDITE ESTE ARCHIVO
**
** Este archivo fue generado automaticamente por https://git.tools.tbk.cl/projects/DSO/repos/mk-tools/browse
**
** 1) Realice sus cambios en `README.doc.yml`
** 2) Ejecute `make docs/all` para reconstruir todos los *.doc.yml
** 3) Ejecute `make README.md` para reconstruir este archivo
**
-->
# aws-vpc

![Last Release](https://ci.tools.tbk.cl/buildStatus/icon?job=tm%2Faws-vpc%2Fmaster&config=lastRelease) [![Build Status](https://ci.tools.tbk.cl/buildStatus/icon?job=tm%2Faws-vpc%2Fmaster)](https://ci.tools.tbk.cl/job/tm/job/aws-vpc/job/master/) 

- [CHANGELOG.md](CHANGELOG.md)
- [Examples](examples)
- [Jira](url a jira para entregar soporte sobre el componente)
- [Teams](link al canal de teams para entregar soporte)

Recurso `aws_vpc` y `aws_subnet`, VPC de AWS y sus subredes públicas y privadas correspondientes.
## Indice

- [Requirements](#requirements)
- [Providers](#providers)
- [Modules](#modules)
- [Resources](#resources)
- [Inputs](#inputs)
- [Outputs](#outputs)
- [Usage](#)

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.12 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 2.0 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 2.2 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 2.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_subnet.subnet](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/subnet) | resource |
| [aws_vpc.vpc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_subnet_tags"></a> [subnet\_tags](#input\_subnet\_tags) | Tags of the Subnet that will be created | `map(string)` | n/a | yes |
| <a name="input_subnets"></a> [subnets](#input\_subnets) | List of subnets to create | <pre>list(object({<br>    name              = string<br>    cidr_block        = string<br>    availability_zone = string<br>    parameter_key     = list(string)<br>    parameter_value   = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_vpc_cidr"></a> [vpc\_cidr](#input\_vpc\_cidr) | CIDR block of the VPC | `string` | n/a | yes |
| <a name="input_vpc_name"></a> [vpc\_name](#input\_vpc\_name) | Name of the VPC that will be created | `string` | n/a | yes |
| <a name="input_vpc_tags"></a> [vpc\_tags](#input\_vpc\_tags) | Tags of the VPC that will be created | `map(string)` | n/a | yes |
| <a name="input_assign_generated_ipv6_cidr_block"></a> [assign\_generated\_ipv6\_cidr\_block](#input\_assign\_generated\_ipv6\_cidr\_block) | (optional parameter) Enables or disables automatic allocation of a system-generated IPv6 CIDR block. The default value is false. | `bool` | `false` | no |
| <a name="input_enable_dns_hostnames"></a> [enable\_dns\_hostnames](#input\_enable\_dns\_hostnames) | (optional parameter) Enables or disables the creation of DNS hostnames for network instances. The default value is false. | `bool` | `false` | no |
| <a name="input_enable_dns_support"></a> [enable\_dns\_support](#input\_enable\_dns\_support) | (optional parameter) Enables or disables DNS support for the network. The default value is true. | `bool` | `true` | no |
| <a name="input_enable_network_address_usage_metrics"></a> [enable\_network\_address\_usage\_metrics](#input\_enable\_network\_address\_usage\_metrics) | (optional parameter) Enables or disables the collection of network address usage metrics. The default value is false. | `bool` | `false` | no |
| <a name="input_instance_tenancy"></a> [instance\_tenancy](#input\_instance\_tenancy) | Instance tenancy (optional parameter) | `string` | `"default"` | no |
| <a name="input_ipv4_ipam_pool_id"></a> [ipv4\_ipam\_pool\_id](#input\_ipv4\_ipam\_pool\_id) | (optional parameter) The ID of the IPv4 IP Address Management (IPAM) pool used to allocate IP addresses in the network. If not specified, Terraform will create a new IPAM pool. | `string` | `null` | no |
| <a name="input_ipv4_netmask_length"></a> [ipv4\_netmask\_length](#input\_ipv4\_netmask\_length) | (optional parameter) The length of the IPv4 subnet mask used to allocate IP addresses in the network. If not specified, Terraform will use the default value. | `string` | `null` | no |
| <a name="input_ipv6_cidr_block"></a> [ipv6\_cidr\_block](#input\_ipv6\_cidr\_block) | (optional parameter) The IPv6 CIDR block used to allocate IP addresses in the network. If not specified, Terraform will create a new CIDR block. | `string` | `null` | no |
| <a name="input_ipv6_cidr_block_network_border_group"></a> [ipv6\_cidr\_block\_network\_border\_group](#input\_ipv6\_cidr\_block\_network\_border\_group) | (optional parameter) The network border group for the IPv6 CIDR block. If not specified, Terraform will use the default value. | `string` | `null` | no |
| <a name="input_ipv6_ipam_pool_id"></a> [ipv6\_ipam\_pool\_id](#input\_ipv6\_ipam\_pool\_id) | (optional parameter) The ID of the IPv6 IPAM pool used to allocate IP addresses in the network. If not specified, Terraform will create a new IPAM pool. | `string` | `null` | no |
| <a name="input_ipv6_netmask_length"></a> [ipv6\_netmask\_length](#input\_ipv6\_netmask\_length) | (optional parameter) The length of the IPv6 subnet mask used to allocate IP addresses in the network. If not specified, Terraform will use the default value. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_subnet_ids"></a> [subnet\_ids](#output\_subnet\_ids) | Id of the subnets |
| <a name="output_vpc_id"></a> [vpc\_id](#output\_vpc\_id) | Id of the vpc that will be created |
# aws-vpc_subnet
Módulo de VPC (Virtual Private Cloud) creada con un CIDR block específico y se le añade un nombre y etiquetas. Las subredes públicas y privadas son creadas con CIDR blocks y etiquetas específicas.

## Usage:

```terraform
module "vpc" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  vpc_cidr              = var.vpc_cidr
  vpc_tags              = var.vpc_tags
  vpc_name              = var.vpc_name
  public_subnet_cidrs   = var.public_subnet_cidrs
  public_azs            = var.public_azs
  private_subnet_cidrs  = var.private_subnet_cidrs
  private_azs           = var.private_azs
  public_subnet_tags    = var.public_subnet_tags
  private_subnet_tags   = var.private_subnet_tags
}
```
### ¿Como colaborar?

#### Obtención del repositorio y generación del Fork

Genere un fork y luego **trabaje en una rama** de su fork

#### Inicie make-tools

Para hacer uso de los comandos de `make` debe ejecutar el siguiente comando. Esto sólo funcionará si se encuentra en una red de confianza, por ejemplo la VPN.

```shell
$ make mk-init
```

#### Instalación de herramientas (opcional)

Para instalar las herramientas de desarrollo con terraform ejecute el siguiente comando.

```shell
$ make terraform/sdk
```

#### Modificaciones de los modulos

Se sugiere el uso del **IDE vscode** instalando el [plugin de terraform](vscode:extension/HashiCorp.terraform).

```shell
$ code .
```

#### Formato del código

Para asegurar que el código este con un formato correcto ejecute

```shell
$ make terraform/fmt
```

#### Actualización de la versión

Configure en el archivo `pipeline.yml` el atributo `metadata.version` con la versión correcta siguiendo [versionamiento semantico](https://semver.org/spec/v2.0.0.html).

#### Actualización de la documentación

Una vez terminado el desarrollo, actualice la documentación del [CHANGELOG.md](CHANGELOG.md) utilizando como input la información de `CHANGELOG.doc.yml`. Puede generar un template de este archivo ejecutando

```shell
$ make changelog/new
```

Si la version actual en desarrollo no existe en `CHANGELOG.doc.yml` la deberá agregar al comienzo del archivo y si ya existe agregue sus cambios en la version y sección correcta.

La generación del [CHANGELOG.md](CHANGELOG.md) se realiza ejecutando

```shell
$ make CHANGELOG.md
```

Luego actualice el archivo [README.md](README.md) ejecutando `make README.md`. Si quiere agregar información adicional puede utilizar las secciones de `README.doc.yml`, si este archivo no existe lo puede generar ejecutando

```shell
$ make docs/new
```

#### Revision de estandares

El pipeline validará que el código esté construido siguiendo las mejores practicas y estandares de la compañia, para ello ejecute el siguiente comando antes de realizar un commit.

```shell
$ make terraform/validate
```

> Si se produce un error, revise la consola para obtener los detalles.

#### Commit y Pull Request (PR)

La etapa final será enviar los cambios de su rama a Bitbucket.

Cuando el desarrollo este finalizado realice un [rebase](https://www.atlassian.com/es/git/tutorials/rewriting-history/git-rebase) de su código para que quede un historial limpio y sólo los commits importantes. Luego un Pull Request desde su rama a la rama develop del upstream.

