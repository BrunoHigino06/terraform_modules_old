# aws-internet_gateway
Módulo de un recurso de Internet Gateway (IGW) con etiquetas específicas.

## Usage:

```terraform
module "igw" {
  source = "git::ssh://git@git.tools.tbk.cl/..."

  igw-tags                = var.igw-tags
  internet_gateway_names  = var.internet_gateway_names
  vpc_id                  = var.vpc_id
}
```
#

